#!/bin/sh

first=$1
shift
echo "$@ $first"
