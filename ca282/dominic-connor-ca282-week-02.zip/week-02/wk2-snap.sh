#!/bin/sh

uniq -d | head -1
