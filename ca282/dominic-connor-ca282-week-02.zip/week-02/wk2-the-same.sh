#!/bin/sh

if [ "$1" = "$2" ]; then
    echo "the same"
else
    echo "different"
fi
