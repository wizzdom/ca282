#!/bin/sh

test -f "$1"
