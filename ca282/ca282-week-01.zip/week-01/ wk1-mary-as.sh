#!/bin/sh

grep " a " mary.txt
