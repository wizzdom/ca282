#!/bin/sh

find . -type d
