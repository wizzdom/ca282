#!/bin/sh

grep "9" data.txt
