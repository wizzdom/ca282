#!/bin/sh

tr -s " " "\n"
