#!/bin/sh

grep "Mary" mary.txt | grep "lamb"
