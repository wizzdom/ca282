#!/bin/sh

mkdir files
tar -xf files.tgz -C files/
