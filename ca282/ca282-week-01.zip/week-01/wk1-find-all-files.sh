#!/bin/sh

find . -type f
