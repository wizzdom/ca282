#!/bin/sh

tar -xf files.tgz
