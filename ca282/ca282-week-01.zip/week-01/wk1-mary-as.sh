#!/bin/sh

grep -i " a " mary.txt

